
const category_item_prefab = `
    <li class="category_item" onclick='window.location="selection.html?name=NAME"'> <a> NAME  </a> </li>
`


const selection_item_prefab = `
    <li class="category_item" onclick='window.location="template.html?category=KAT&name=NAME"'> <a> 
        <img src="data/categories/KAT/NAME/english.png">
    </a> </li>
`