
const category_item_prefab = `
    <li class="category_item" onclick='window.location="selection.aspx?name=NAME"'> <img src="data/categories/NAME/icon.png"> <a> NAME  </a> </li>
`


const selection_item_prefab = `
    <li class="category_item" onclick='window.location="template.aspx?category=KAT&name=NAME"'> <a> 
        <img src="data/categories/KAT/NAME">
    </a> </li>
`